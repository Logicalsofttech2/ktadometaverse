cat views/chat.ejs  public/javascripts/chat.js index.js public/stylesheets/style.css > cat.jshtml
